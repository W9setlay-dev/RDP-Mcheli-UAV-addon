package net.vas.rdp.uav.mission;

import com.norwood.mcheli.aircraft.MCH_EntityAircraft;
import com.norwood.mcheli.helicopter.MCH_EntityHeli;
import com.norwood.mcheli.wingman.wingman.WingmanEntry;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityList;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;
import net.vas.rdp.uav.flight.WingManFlightAdapter;
import net.vas.rdp.uav.persistence.RDPMissionWorldData;
import net.vas.rdp.uav.scan.RDPScanReport;
import net.vas.rdp.uav.scan.RDPScanReportRepository;
import net.vas.rdp.uav.profile.UavVehicleProfile;
import net.vas.rdp.uav.profile.UavVehicleProfiles;
import net.vas.rdp.uav.profile.VehicleCapability;
import net.vas.rdp.uav.target.TargetSelectionMode;
import net.vas.rdp.uav.target.ContactLifecycle;
import net.vas.rdp.uav.target.ContactSnapshot;
import net.vas.rdp.uav.target.TargetAuthority;
import net.vas.rdp.uav.target.TargetPolicy;
import net.vas.rdp.uav.target.TargetResolver;
import net.vas.rdp.uav.target.TargetClassifier;
import net.vas.rdp.uav.flight.KamikazeImpactDetector;
import net.vas.rdp.uav.flight.KamikazePilotOverride;
import net.vas.rdp.uav.flight.TerrainRoutePlanner;
import net.vas.rdp.uav.weapon.GuidedStrikeObjective;
import net.vas.rdp.uav.weapon.GuidedWeaponAdapter;
import net.vas.rdp.uav.weapon.GuidedWeaponDecision;
import net.vas.rdp.uav.world.ChunkState;
import net.vas.rdp.uav.world.MinecraftWorldPerceptionAdapter;
import net.vas.rdp.uav.world.WorldPerceptionAdapter;

import java.util.Map;
import java.util.HashMap;
import java.util.WeakHashMap;
import java.util.List;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import net.vas.rdp.uav.RdpUavDebug;

/**
 * Server-side bridge between persisted RDP missions and WingMan.
 *
 * <p>WingMan owns route sequencing. For an active mission, the RDP flight
 * computer owns the final leased attitude/throttle setpoints; this lifecycle
 * coordinates dispatch, target policy, mission outcomes, and recovery state.</p>
 */
public final class MissionLifecycle {
    private static final Logger LOGGER = LogManager.getLogger("RDP-UAV/MissionLifecycle");
    static final long MISSION_TIMEOUT = 12000L;
    private static final long PROJECTILE_OBSERVATION_TIMEOUT = 100L;
    private static final long EFFECT_CONFIRMATION_TIMEOUT = 100L;
    private static final long WINGMAN_ENTRY_GRACE_TICKS = 20L;
    private static final long GUIDANCE_RETRY_INTERVAL = 10L;
    private static final long TARGET_LOSS_GRACE_TICKS = 40L;

    private final MissionManager manager;
    private final WingManFlightAdapter flight = new WingManFlightAdapter();
    private final GuidedWeaponAdapter guidedWeapons = new GuidedWeaponAdapter(flight);
    private final TargetAuthority targets = new TargetAuthority();
    private final WorldPerceptionAdapter perception = new MinecraftWorldPerceptionAdapter();
    /** Operator cursor is deliberately separate from RDPMission.targetId (the mission lock). */
    private final Map<UUID, UUID> operatorContacts = new HashMap<>();
    private final Map<World, Boolean> restoredWorlds = new WeakHashMap<>();
    private final Map<UUID, RouteRefresh> routeRefreshes = new HashMap<>();
    private Map<UUID, MCH_EntityAircraft> aircraftThisTick = new HashMap<>();

    public MissionLifecycle(MissionManager manager) {
        if (manager == null) throw new IllegalArgumentException("Mission manager is required");
        this.manager = manager;
    }

    public void tick(World world) {
        if (world == null || world.isRemote) return;
        aircraftThisTick = indexAircraft(world);
        restoreQueue(world);
        dispatchQueued(world);
        updateActive(world);
    }

    public void applyNativeControls(World world) {
        if (world == null || world.isRemote) return;
        long tick = world.getTotalWorldTime();
        for (Entity entity : world.loadedEntityList) {
            if (!(entity instanceof MCH_EntityAircraft)) continue;
            MCH_EntityAircraft aircraft = (MCH_EntityAircraft) entity;
            RDPMission mission = manager.activeMission(world, aircraft.getUniqueID());
            if (mission != null) {
                flight.applyNativeControl(world, manager, aircraft, mission, tick);
            }
        }
    }

    private void restoreQueue(World world) {
        synchronized (restoredWorlds) {
            if (restoredWorlds.containsKey(world)) return;
            restoredWorlds.put(world, Boolean.TRUE);
        }
        manager.restoreAssignments(world);
        manager.restoreQueued(world);
    }

    private void dispatchQueued(World world) {
        int count = manager.queuedMissionCount();
        for (int i = 0; i < count; i++) {
            RDPMission mission = manager.pollQueuedMission();
            if (mission == null) return;
            if (mission.isPaused()) {
                manager.enqueueQueuedMission(mission);
                continue;
            }
            if (mission.getDimension() != world.provider.getDimension()) {
                RdpUavDebug.debug("Lifecycle", "mission {} deferred for dimension {} (current {})",
                        mission.getMissionId(), mission.getDimension(), world.provider.getDimension());
                manager.enqueueQueuedMission(mission);
                continue;
            }
            /*
             * A persisted queue flag can outlive the state transition that
             * consumed the mission (for example after a save during target
             * locking). Such a mission is already in the active state
             * machine; dispatching it again would attempt TARGET_LOCKED ->
             * DISPATCHED and stall it forever.
             */
            if (mission.getState() != MissionState.PLANNED) {
                mission.setQueued(false);
                RdpUavDebug.debug("Lifecycle",
                        "mission {} queue flag repaired state={}",
                        mission.getMissionId(), mission.getState());
                RDPMissionWorldData.get(world).markDirty();
                continue;
            }
            dispatch(world, mission);
        }
    }

    private void dispatch(World world, RDPMission mission) {
        long tick = world.getTotalWorldTime();
        if (mission.isTimedOut(tick, MISSION_TIMEOUT)) {
            fail(world, mission, "MISSION_TIMEOUT", tick);
            return;
        }
        MCH_EntityAircraft aircraft = findAircraft(world, mission.getAircraftId());
        if (tick % 5L == 0L) {
            RdpUavDebug.event("MissionRuntime", "MISSION_DISPATCH_ATTEMPT",
                    "mission", mission.getMissionId(), "aircraft", mission.getAircraftId(),
                    "tick", tick, "state", mission.getState(),
                    "aircraftPresent", aircraft != null);
        }
        if (aircraft == null) {
            RdpUavDebug.debug("Lifecycle", "mission {} waiting for aircraft {}",
                    mission.getMissionId(), mission.getAircraftId());
            defer(world, mission, "AIRCRAFT_NOT_FOUND", MissionState.WAITING_FOR_WORLD, tick);
            return;
        }
        if (aircraft.getAcInfo() == null) {
            defer(world, mission, "AIRCRAFT_METADATA_UNAVAILABLE",
                    MissionState.WAITING_FOR_WORLD, tick);
            return;
        }
        UavVehicleProfile vehicleProfile = profile(aircraft);
        if (aircraft.isUAV()) {
            String capabilityFailure = VehicleCapability.fromProfile(vehicleProfile)
                    .validateMission(mission.getMissionType(), mission.isAttack());
            if (capabilityFailure != null) {
                fail(world, mission, capabilityFailure, tick);
                return;
            }
        }
        // MissionManager.create already assigned this aircraft. Re-registering
        // it here would replace the ON_MISSION record with a fresh READY
        // record and allow a second mission to claim the same entity.
        if (flight.isFuelInsufficientForMission(aircraft)) {
            defer(world, mission, "INSUFFICIENT_FUEL", MissionState.WAITING_FOR_FUEL, tick);
            return;
        }
        if (mission.isAttack() && !flight.hasAttackAmmunition(aircraft)
                && !flight.hasSelfDestructWeaponWithAmmo(aircraft)) {
            fail(world, mission, "NO_ATTACK_AMMUNITION", tick);
            return;
        }
        if (mission.getMissionType() == MissionType.PATROL) {
            dispatchPatrol(world, mission, aircraft, tick);
            return;
        }

        Target target = locateTarget(world, aircraft, mission);
        if (tick % 5L == 0L) {
            RdpUavDebug.event("MissionRuntime", "TARGET_LOOKUP",
                    "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                    "tick", tick, "found", target != null,
                    "target", formatTarget(target));
        }
        RdpUavDebug.debug("Lifecycle", "mission {} target lookup result={} state={}",
                mission.getMissionId(), formatTarget(target), mission.getState());
        if (target == null) {
            defer(world, mission, "TARGET_NOT_AVAILABLE", MissionState.WAITING_FOR_TARGET, tick);
            return;
        }
        double dispatchRange = Math.max(mission.getMissionRangeLimit(),
                profile(aircraft).getDetectionRange());
        if (aircraft.getDistance(target.x, target.y, target.z) > dispatchRange) {
            defer(world, mission, "OUT_OF_RANGE_REPLAN", MissionState.REPLAN, tick);
            return;
        }

        try {
            /*
             * WingMan deliberately controls UAVs only. A piloted/non-UAV
             * aircraft may still release a configured guided weapon through
             * McHeli's native weapon API; do that once the server has made
             * the same target and ammunition checks as an autonomous route.
             */
            if (mission.isAttack() && !aircraft.isUAV()
                    && profile(aircraft).getExecutionProfile()
                    != net.vas.rdp.uav.profile.UavExecutionProfile.ONE_WAY) {
                GuidedStrikeObjective objective = target.entity == null
                        ? GuidedStrikeObjective.square(mission.getMissionId(),
                        world.provider.getDimension(), target.x, target.y, target.z, tick)
                        : GuidedStrikeObjective.entity(mission.getMissionId(),
                        target.entity.getUniqueID(), world.provider.getDimension(),
                        target.x, target.y, target.z, tick);
                objective.authorize();
                objective.beginTracking();
                GuidedWeaponDecision guided = guidedWeapons.arm(world, aircraft, objective,
                        aircraftSpeed(aircraft), profile(aircraft).getAttackEnvelope(), true,
                        weaponPriority(mission, aircraft));
                if (!guided.isAccepted()) {
                    if (isPermanentGuidanceFailure(guided.getReason())) {
                        fail(world, mission, guided.getReason(), tick);
                    } else {
                        defer(world, mission, guided.getReason(),
                                guidanceRecoveryState(guided.getReason()), tick);
                    }
                    return;
                }
                if (mission.getState() == MissionState.PLANNED) {
                    mission.transitionTo(MissionState.DISPATCHED, tick);
                    mission.transitionTo(MissionState.TAKEOFF, tick);
                    mission.transitionTo(MissionState.CRUISE, tick);
                    mission.transitionTo(MissionState.SEARCHING, tick);
                }
                mission.transitionTo(MissionState.TARGET_ACQUIRED, tick);
                if (target.entity == null) mission.lockPoint(tick);
                else mission.lockTarget(target.entity.getUniqueID(), tick);
                mission.transitionTo(MissionState.LAUNCH_ACCEPTED, tick);
                manager.release(mission);
                RDPMissionWorldData.get(world).markDirty();
                return;
            }
            double guidanceY = terminalRouteAltitude(aircraft, target);
            if (target.entity != null && mission.getTargetId() == null) {
                mission.reacquireTarget(target.entity.getUniqueID(), tick);
            }
            mission.transitionTo(MissionState.DISPATCHED, tick);
            mission.transitionTo(MissionState.TAKEOFF, tick);
            mission.transitionTo(MissionState.CRUISE, tick);
            mission.transitionTo(MissionState.SEARCHING, tick);

            // WingMan must fly the real aircraft to the observation point
            // before the mission reports acquisition or arms an attack.
            if (!MissionMovementAuthority.claimControl(mission, aircraft.getUniqueID(), tick)) {
                RdpUavDebug.event("MissionRuntime", "ROUTE_DISPATCH",
                        "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                        "tick", tick, "accepted", false, "reason", "CONTROL_LEASE_REJECTED",
                        "target", formatTarget(target));
                defer(world, mission, "CONTROL_LEASE_REJECTED",
                        MissionState.EXECUTION_STALLED, tick);
            } else if (!flight.dispatch(aircraft, target.x, guidanceY, target.z,
                    mission.getObservationDistance(), 200, mission.isAttack(), mission.getTargetId())) {
                RdpUavDebug.event("MissionRuntime", "ROUTE_DISPATCH",
                        "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                        "tick", tick, "accepted", false, "target", formatTarget(target));
                defer(world, mission, "WINGMAN_DISPATCH_REJECTED",
                        MissionState.EXECUTION_STALLED, tick);
            } else {
                mission.beginRouteProgressWindow(tick);
                WingmanEntry routeEntry = flight.getEntry(aircraft);
                RdpUavDebug.event("MissionRuntime", "ROUTE_DISPATCH",
                        "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                        "tick", tick, "accepted", true,
                        "routeSize", routeEntry == null || routeEntry.mission == null
                                ? 0 : routeEntry.mission.size(),
                        "missionIndex", routeEntry == null ? -1 : routeEntry.missionIndex,
                        "nodeTimer", routeEntry == null ? -1 : routeEntry.missionNodeTimer,
                        "node", routeEntry == null || routeEntry.currentNode() == null
                                ? null : routeEntry.currentNode().type,
                        "target", formatTarget(target));
                mission.setQueued(false);
                LOGGER.info("Mission {} dispatched aircraft {} type={} target={} at tick {}",
                        mission.getMissionId(), aircraft.getUniqueID(), mission.getAircraftType(),
                        formatTarget(target), tick);
            }
        } catch (RuntimeException failure) {
            defer(world, mission, failure.getMessage() == null
                ? "MISSION_DISPATCH_RETRY_REQUIRED" : failure.getMessage(),
                MissionState.EXECUTION_STALLED, tick);
        }
        RDPMissionWorldData.get(world).markDirty();
    }

    private void updateActive(World world) {
        long tick = world.getTotalWorldTime();
        List<RDPMission> missions = RDPMissionWorldData.get(world).getRepository().snapshot();
        boolean dirty = false;
        for (RDPMission mission : missions) {
            if (mission.isQueued() || mission.getDimension() != world.provider.getDimension()) continue;
            if (terminal(mission.getState())) {
                manager.release(mission);
                continue;
            }
            if (mission.isTimedOut(tick, MISSION_TIMEOUT)) {
                fail(world, mission, "MISSION_TIMEOUT", tick);
                dirty = true;
                continue;
            }
            if (mission.getState() == MissionState.LAUNCH_ACCEPTED
                    || mission.getState() == MissionState.DIRECT_LAUNCH_COMPLETE) {
                if (net.vas.rdp.uav.weapon.MissileGuidanceController
                        .isProjectileTracked(mission.getMissionId())) {
                    mission.transitionTo(MissionState.PROJECTILE_TRACKED, tick);
                    RDPMissionWorldData.get(world).markDirty();
                } else if (net.vas.rdp.uav.weapon.MissileGuidanceController
                        .isProjectileOutcomeUnknown(mission.getMissionId())
                        || tick - mission.getLastUpdateTick() > PROJECTILE_OBSERVATION_TIMEOUT) {
                    mission.transitionTo(MissionState.OUTCOME_UNKNOWN, tick);
                    RdpUavDebug.event("MissionRuntime", "PAYLOAD_OUTCOME_UNKNOWN",
                            "mission", mission.getMissionId(),
                            "aircraft", mission.getAircraftId(),
                            "state", mission.getState(),
                            "reason", net.vas.rdp.uav.weapon.MissileGuidanceController
                                    .isProjectileOutcomeUnknown(mission.getMissionId())
                                    ? "PROJECTILE_DISAPPEARED_WITHOUT_IMPACT"
                                    : "PROJECTILE_NOT_OBSERVED_WITHIN_TIMEOUT",
                            "tick", tick);
                    RDPMissionWorldData.get(world).markDirty();
                }
                continue;
            }
            if (mission.getState() == MissionState.PROJECTILE_TRACKED
                    && net.vas.rdp.uav.weapon.MissileGuidanceController
                    .projectileStateForObjective(mission.getMissionId())
                    == net.vas.rdp.uav.weapon.ProjectileGuidanceState.IMPACTED) {
                mission.transitionTo(MissionState.IMPACT_OBSERVED, tick,
                        "IMPACT_OBSERVED");
                RDPMissionWorldData.get(world).markDirty();
                continue;
            }
            if (mission.getState() == MissionState.IMPACT_OBSERVED
                    && net.vas.rdp.uav.weapon.MissileGuidanceController
                    .effectConfirmedForObjective(mission.getMissionId())) {
                mission.transitionTo(MissionState.EFFECT_CONFIRMED, tick,
                        "EFFECT_CONFIRMED");
                RDPMissionWorldData.get(world).markDirty();
                continue;
            }
            if (mission.getState() == MissionState.IMPACT_OBSERVED
                    && tick - mission.getLastUpdateTick() > EFFECT_CONFIRMATION_TIMEOUT) {
                mission.transitionTo(MissionState.OUTCOME_UNKNOWN, tick,
                        "NATIVE_EFFECT_NOT_CONFIRMED");
                RdpUavDebug.event("MissionRuntime", "PAYLOAD_OUTCOME_UNKNOWN",
                        "mission", mission.getMissionId(),
                        "aircraft", mission.getAircraftId(),
                        "state", mission.getState(),
                        "reason", "NATIVE_EFFECT_NOT_CONFIRMED",
                        "tick", tick);
                RDPMissionWorldData.get(world).markDirty();
                continue;
            }
            if (mission.getState() == MissionState.PROJECTILE_TRACKED
                    && net.vas.rdp.uav.weapon.MissileGuidanceController
                    .isProjectileOutcomeUnknown(mission.getMissionId())) {
                mission.transitionTo(MissionState.OUTCOME_UNKNOWN, tick);
                RdpUavDebug.event("MissionRuntime", "PAYLOAD_OUTCOME_UNKNOWN",
                        "mission", mission.getMissionId(),
                        "aircraft", mission.getAircraftId(),
                        "state", mission.getState(),
                        "reason", "PROJECTILE_DISAPPEARED_WITHOUT_IMPACT",
                        "tick", tick);
                RDPMissionWorldData.get(world).markDirty();
                continue;
            }
            if (mission.isPaused()) {
                MissionMovementAuthority.releaseControl(
                        mission.getAircraftId(), mission.getMissionId());
                flight.clearGuidance(findAircraft(world, mission.getAircraftId()));
                continue;
            }
            if (mission.getState() != MissionState.HOLDING
                    && mission.getState() != MissionState.WAITING_FOR_FUEL
                    && tick - mission.getLastUpdateTick() > MISSION_TIMEOUT) {
                defer(world, mission, mission.getState().name() + "_TIMEOUT",
                        MissionState.EXECUTION_STALLED, tick);
                dirty = true;
                continue;
            }
            if (mission.getState() == MissionState.KAMIKADZE_TARGET
                    && tick - mission.getLastUpdateTick()
                    > net.vas.rdp.uav.flight.KamikazeConfig.terminalTimeoutTicks) {
                flight.markTerminalTimeout(mission.getAircraftId());
                // Use the shared terminal-failure path so the assignment,
                // movement lease, and WingMan controller are released too.
                fail(world, mission, "TERMINAL_TIMEOUT", tick);
                RdpUavDebug.event("TerminalGuidance", "TERMINAL_TIMEOUT",
                        "mission", mission.getMissionId(), "target", mission.getTargetId(),
                        "tick", tick, "phase", mission.getPhase(),
                        "controlOwner", mission.getControlOwner());
                RdpUavDebug.debug("Lifecycle",
                        "mission {} terminal guidance timed out aircraft={} tick={}",
                        mission.getMissionId(), mission.getAircraftId(), tick);
                dirty = true;
                continue;
            }

            MCH_EntityAircraft aircraft = findAircraft(world, mission.getAircraftId());
            if (aircraft == null) {
                if (mission.getState() == MissionState.KAMIKADZE_TARGET) {
                    // Destruction/removal is not evidence that the self-destruct
                    // payload fired or that a world effect was produced.
                    mission.transitionTo(MissionState.AIRCRAFT_LOST, tick,
                            "AIRCRAFT_LOST_BEFORE_EFFECT_CONFIRMATION");
                    RdpUavDebug.event("TerminalGuidance", "AIRCRAFT_LOST",
                            "mission", mission.getMissionId(),
                            "aircraft", mission.getAircraftId(),
                            "target", mission.getTargetId(),
                            "tick", tick,
                            "reason", "EFFECT_NOT_CONFIRMED");
                    MissionMovementAuthority.releaseControl(
                            mission.getAircraftId(), mission.getMissionId());
                    manager.release(mission);
                    dirty = true;
                    continue;
                }
                defer(world, mission, "AIRCRAFT_UNAVAILABLE", MissionState.WAITING_FOR_WORLD, tick);
                dirty = true;
                continue;
            }
            /*
             * The lease is renewed on every active server tick. This also
             * repairs a lease lost across a server reload, while still
             * rejecting takeover when another mission owns the aircraft.
             */
            if (!MissionMovementAuthority.claimControl(mission, aircraft.getUniqueID(), tick)) {
                RdpUavDebug.event("MissionRuntime", "CONTROL_LEASE_REJECTED",
                        "mission", mission.getMissionId(),
                        "aircraft", aircraft.getUniqueID(),
                        "tick", tick,
                        "state", mission.getState());
                defer(world, mission, "CONTROL_LEASE_REJECTED",
                        MissionState.EXECUTION_STALLED, tick);
                dirty = true;
                continue;
            }
            flight.observeAircraftState(aircraft, mission, tick);
            if (mission.getState() == MissionState.WAITING_FOR_FUEL
                    && flight.isFuelInsufficientForMission(aircraft)) {
                dirty = true;
                continue;
            }
            if (mission.getState() == MissionState.WAITING_FOR_WORLD
                    || mission.getState() == MissionState.WAITING_FOR_FUEL
                    || mission.getState() == MissionState.EXECUTION_STALLED
                    || mission.getState() == MissionState.RECOVERING
                    || mission.getState() == MissionState.REPLAN) {
                if (mission.getState() != MissionState.REPLAN) {
                    mission.transitionTo(MissionState.REPLAN, tick);
                }
                dirty = true;
            }
            if (flight.isFuelInsufficientForMission(aircraft)
                    && mission.getState() != MissionState.RETURNING
                    && mission.getState() != MissionState.LANDING
                    && mission.getState() != MissionState.PARKING) {
                // Low fuel is reported to the operator; autonomous mission
                // logic must never initiate RTB.  The player can explicitly
                // request native return through the GUI or command.
                defer(world, mission, "INSUFFICIENT_FUEL",
                        MissionState.WAITING_FOR_FUEL, tick);
                dirty = true;
                continue;
            }
            if (mission.isAttack() && mission.getState() == MissionState.TARGET_LOCKED
                    && !flight.hasAttackAmmunition(aircraft)
                    && !flight.hasSelfDestructWeaponWithAmmo(aircraft)) {
                fail(world, mission, "AMMUNITION_DEPLETED", tick);
                dirty = true;
                continue;
            }

            Target target = mission.getTargetSelectionMode() == TargetSelectionMode.POINT
                    ? resolvePointTarget(world, mission.getTargetSpec().getX(),
                    mission.getTargetSpec().getY(), mission.getTargetSpec().getZ())
                    : reacquire(world, aircraft, mission, tick);
            if (mission.getTargetSelectionMode() != TargetSelectionMode.POINT && target == null) {
                if (mission.getTargetId() != null) {
                    long lastObservedTick = mission.getLastTargetTick();
                    ContactSnapshot trackedContact = targets.get(mission.getTargetId());
                    if (trackedContact != null) {
                        lastObservedTick = Math.max(lastObservedTick,
                                trackedContact.getLastDetectionTick());
                    }
                    boolean inGrace = lastObservedTick >= 0L
                            && tick >= lastObservedTick
                            && tick - lastObservedTick <= TARGET_LOSS_GRACE_TICKS;
                    if (mission.getState() == MissionState.KAMIKADZE_TARGET) {
                        // Once terminal guidance is committed, preserve the
                        // last finite terminal route during the brief loss
                        // grace. After that, hold a straight leg until the
                        // existing bounded terminal timeout ends the mission.
                        if (!inGrace) flight.holdForTargetReacquisition(aircraft);
                        if (!inGrace && tick % 20L == 0L) {
                            RdpUavDebug.event("TerminalGuidance", "TARGET_TRACK_UNAVAILABLE",
                                    "mission", mission.getMissionId(),
                                    "target", mission.getTargetId(),
                                    "lastObservedTick", lastObservedTick,
                                    "graceTicks", TARGET_LOSS_GRACE_TICKS,
                                    "tick", tick);
                        }
                        continue;
                    }
                    flight.holdForTargetReacquisition(aircraft);
                    if (inGrace) {
                        if (tick % 20L == 0L) {
                            RdpUavDebug.event("TargetTracking", "TARGET_LOSS_GRACE",
                                    "mission", mission.getMissionId(),
                                    "target", mission.getTargetId(),
                                    "ageTicks", tick - lastObservedTick,
                                    "graceTicks", TARGET_LOSS_GRACE_TICKS,
                                    "state", mission.getState(), "tick", tick);
                        }
                        continue;
                    }
                    if (mission.getState() == MissionState.LOST) {
                        mission.transitionTo(MissionState.WAITING_FOR_TARGET, tick,
                                "TARGET_LOSS_GRACE_EXPIRED");
                        dirty = true;
                        continue;
                    }
                    if (mission.getState() == MissionState.WAITING_FOR_TARGET) {
                        continue;
                    }
                    if (mission.getState().canTransitionTo(MissionState.LOST)) {
                        MissionState previousState = mission.getState();
                        mission.transitionTo(MissionState.LOST, tick,
                                "TARGET_LOSS_GRACE_EXPIRED");
                        RdpUavDebug.event("TargetTracking", "TARGET_LOST",
                                "mission", mission.getMissionId(),
                                "target", mission.getTargetId(),
                                "lastObservedTick", lastObservedTick,
                                "graceTicks", TARGET_LOSS_GRACE_TICKS,
                                "previousState", previousState, "tick", tick);
                        dirty = true;
                        continue;
                    }
                    if (mission.getState().canTransitionTo(MissionState.WAITING_FOR_TARGET)) {
                        mission.transitionTo(MissionState.WAITING_FOR_TARGET, tick,
                                "TARGET_LOSS_GRACE_EXPIRED");
                        dirty = true;
                        continue;
                    }
                }
                if (profile(aircraft).isHelicopterProfile()) flight.enterFpvHover(aircraft);
                flight.clearGuidance(aircraft);
                if (mission.isAttack() && !profile(aircraft).isHelicopterProfile()) {
                    flight.release(aircraft);
                }
                if (mission.getState() == MissionState.SEARCHING
                        || mission.getState() == MissionState.WAITING_FOR_TARGET) {
                    if (mission.getState() == MissionState.SEARCHING) {
                        mission.transitionTo(MissionState.WAITING_FOR_TARGET, tick);
                    }
                    RdpUavDebug.debug("Lifecycle",
                            "mission {} waiting for target reason=NO_CANDIDATE aircraft={}",
                            mission.getMissionId(), aircraft.getUniqueID());
                    dirty = true;
                    continue;
                }
                if (mission.getState() == MissionState.LOST) {
                    mission.transitionTo(MissionState.WAITING_FOR_TARGET, tick);
                    dirty = true;
                    continue;
                }
                if (mission.getState() == MissionState.REPLAN) {
                    RdpUavDebug.debug("Lifecycle",
                            "mission {} replan waiting for original target aircraft={}",
                            mission.getMissionId(), aircraft.getUniqueID());
                    dirty = true;
                    continue;
                }
                if (requiresTarget(mission.getState())) {
                    mission.clearTarget("TARGET_LOST_NO_CANDIDATE", tick);
                    mission.transitionTo(MissionState.LOST, tick);
                    RdpUavDebug.debug("Lifecycle",
                            "mission {} target lost reason=NO_CANDIDATE aircraft={}",
                            mission.getMissionId(), aircraft.getUniqueID());
                    dirty = true;
                    continue;
                }
            } else if (mission.getState() == MissionState.WAITING_FOR_TARGET
                    || mission.getState() == MissionState.LOST) {
                mission.transitionTo(MissionState.SEARCHING, tick);
                dirty = true;
            }
            if (mission.getTargetSelectionMode() != TargetSelectionMode.POINT && target == null
                    && requiresTarget(mission.getState())) {
                continue;
            }
            if (mission.getState() == MissionState.WAITING_FOR_TARGET
                    || mission.getState() == MissionState.LOST) {
                dirty = true;
                continue;
            }
            if (mission.getState() == MissionState.KAMIKADZE_TARGET) {
                if (target != null && target.entity != null) {
                    flight.updateTerminalGuidance(aircraft, target.entity,
                            terminalRouteAltitude(aircraft, target), tick,
                            mission.getMissionId(), mission.getPhase().name(),
                            mission.getControlOwner().name());
                    String terminalFailure = flight.terminalGuidanceFailureReason(aircraft);
                    if (terminalFailure != null && !mission.isKamikazePayloadLaunched()) {
                        fail(world, mission, terminalFailure, tick);
                        dirty = true;
                        continue;
                    }
                }
                boolean noseImpact = KamikazeImpactDetector.hasNoseImpact(aircraft);
                boolean speedReached = flight.isKamikazeSpeedReached(aircraft);
                boolean targetInRadius = target != null
                        && targetDistance(aircraft, target)
                        <= net.vas.rdp.uav.flight.KamikazeConfig.detonationRadius;
                boolean terminalGeometry = target != null
                        && terminalGeometrySatisfied(aircraft, target, mission);
                if (!speedReached || (!noseImpact && !targetInRadius) || !terminalGeometry) {
                    if (tick % 20L == 0L) {
                        RdpUavDebug.debug("Lifecycle",
                                "mission {} kamikaze approaching aircraft={} speedReached={} targetDistance={} target={}",
                                mission.getMissionId(), aircraft.getUniqueID(),
                                speedReached,
                                target == null ? null : targetDistance(aircraft, target),
                                formatTarget(target));
                    }
                    continue;
                }
                if (!mission.isKamikazePayloadLaunched()
                        && flight.detonateSelfDestructWeapon(aircraft,
                        target.x,
                        target.y,
                        target.z, true)) {
                    LOGGER.info("Mission {} kamikaze payload launch accepted aircraft={} impact={} inRadius={} target={} tick={}",
                            mission.getMissionId(), aircraft.getUniqueID(), noseImpact,
                            targetInRadius, formatTarget(target), tick);
                    mission.markKamikazePayloadLaunched(tick);
                    confirmKamikazeEffect(world, mission, tick);
                    RdpUavDebug.event("TerminalGuidance", "PAYLOAD_LAUNCH_ACCEPTED",
                            "mission", mission.getMissionId(),
                            "aircraft", mission.getAircraftId(),
                            "target", mission.getTargetId(), "tick", tick);
                    RDPMissionWorldData.get(world).markDirty();
                    dirty = true;
                    continue;
                }
                LOGGER.debug("Mission {} kamikaze trigger reached but weapon not ready aircraft={} impact={} inRadius={}",
                        mission.getMissionId(), aircraft.getUniqueID(), noseImpact, targetInRadius);
                // A collision can be detected while the weapon is still on
                // cooldown, or before the target is inside the detonation
                // radius. Keep the armed mission alive and retry next tick.
                if (tick % 20L == 0L) {
                    RdpUavDebug.debug("Lifecycle",
                            "mission {} kamikaze waiting aircraft={} targetDistance={} target={}",
                            mission.getMissionId(), aircraft.getUniqueID(),
                            targetDistance(aircraft, target),
                            formatTarget(target));
                }
                continue;
            }

            MissionState before = mission.getState();
            if (updateMission(world, mission, aircraft, target, tick)) dirty = true;
            emitMissionSnapshot(mission, aircraft, target, tick);
            if (before != mission.getState()) {
                LOGGER.info("Mission {} state {} -> {} aircraft={} wingman={}",
                        mission.getMissionId(), before, mission.getState(),
                        aircraft.getUniqueID(), describeWingman(flight.getEntry(aircraft)));
            } else if (tick % 20L == 0L) {
                LOGGER.debug("Mission {} state={} aircraft={} wingman={}",
                        mission.getMissionId(), mission.getState(), aircraft.getUniqueID(),
                        describeWingman(flight.getEntry(aircraft)));
            }
            if (terminal(mission.getState())) {
                boolean ownsAircraft = manager.ownsAssignment(mission);
                if (ownsAircraft) flight.release(aircraft);
                manager.release(mission);
                if (ownsAircraft) routeRefreshes.remove(aircraft.getUniqueID());
                dirty = true;
            }
        }
        if (dirty) RDPMissionWorldData.get(world).markDirty();
    }

    private double targetDistance(MCH_EntityAircraft aircraft, Target target) {
        if (target == null) return Double.NaN;
        if (target.entity != null) return target.entity.getDistance(aircraft);
        double dx = aircraft.posX - target.x;
        double dy = aircraft.posY - target.y;
        double dz = aircraft.posZ - target.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private boolean routeAlreadyDispatched(MCH_EntityAircraft aircraft, Target target, RDPMission mission) {
        if (aircraft == null || target == null || mission == null) return false;
        WingmanEntry entry = flight.getEntry(aircraft);
        if (entry == null || entry.mission == null) return false;
        if (entry.autoState == com.norwood.mcheli.wingman.mission.AutonomousState.RTB
                || entry.autoState == com.norwood.mcheli.wingman.mission.AutonomousState.LANDING
                || entry.autoState == com.norwood.mcheli.wingman.mission.AutonomousState.PARKED) {
            return false;
        }
        if (entry.autoTargetX == 0.0D && entry.autoTargetY == 0.0D && entry.autoTargetZ == 0.0D
                && target.x == 0.0D && target.y == 0.0D && target.z == 0.0D) {
            return true;
        }
        double dx = entry.autoTargetX - target.x;
        double dy = entry.autoTargetY - target.y;
        double dz = entry.autoTargetZ - target.z;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        boolean singleNode = entry.mission.size() <= 1;
        boolean routeComplete = entry.missionIndex >= Math.max(0, entry.mission.size() - 1)
                && (flight.hasReachedRoutePoint(aircraft) || singleNode);
        return distance <= 2.0D && (singleNode || routeComplete);
    }

    private boolean updateMission(World world, RDPMission mission, MCH_EntityAircraft aircraft,
                                  Target target, long tick) {
        if (mission.isTerminal()) return false;
        if (mission.getMissionType() == MissionType.PATROL) {
            return updatePatrol(world, mission, aircraft, tick);
        }
        if (mission.getState() == MissionState.REPLAN && target != null
                && isDirectNativeWeaponMission(mission, aircraft)) {
            if (tick - mission.getLastUpdateTick() < GUIDANCE_RETRY_INTERVAL) {
                return false;
            }
            launchDirectWeapon(world, mission, aircraft, target, tick);
            return true;
        }
        if (mission.getState() == MissionState.REPLAN && target != null) {
            String replanReason = mission.getLastTransitionReason();
            boolean stalledRoute = "NO_PROGRESS_TIMEOUT".equals(replanReason)
                    || "ROUTE_STALLED_TARGET_RETAINED".equals(replanReason)
                    || "ROUTE_STALLED_NO_TARGET".equals(replanReason);
            if (!stalledRoute && routeAlreadyDispatched(aircraft, target, mission)) {
                if (mission.getTargetSelectionMode() == TargetSelectionMode.POINT) {
                    mission.transitionTo(MissionState.TARGET_LOCKED, tick);
                }
                return false;
            }
            flight.release(aircraft);
            double routeY = terminalRouteAltitude(aircraft, target);
            if (!flight.dispatch(aircraft, target.x, routeY, target.z,
                    mission.getObservationDistance(), 200, mission.isAttack(),
                    target.entity == null ? null : target.entity.getUniqueID())) {
                defer(world, mission, "REPLAN_DISPATCH_REJECTED",
                        MissionState.EXECUTION_STALLED, tick);
                return true;
            }
            mission.beginRouteProgressWindow(tick);
            mission.transitionTo(MissionState.SEARCHING, tick);
            return true;
        }
        WingmanEntry entry = flight.getEntry(aircraft);
        if (entry == null) {
            RdpUavDebug.debug("Lifecycle", "mission {} WingMan entry missing age={}",
                    mission.getMissionId(), tick - mission.getCreatedTick());
            if (tick - mission.getCreatedTick() <= WINGMAN_ENTRY_GRACE_TICKS) {
                return false;
            }
            defer(world, mission, "WINGMAN_ENTRY_UNAVAILABLE",
                    MissionState.EXECUTION_STALLED, tick);
            return true;
        }
        if (target != null) {
            double targetGuidanceY = terminalRouteAltitude(aircraft, target);
            if (target.entity != null) {
                flight.updateMovingEntityGuidance(aircraft, target.entity,
                        targetGuidanceY, tick);
            } else {
                flight.updateTargetGuidance(aircraft, target.x, targetGuidanceY, target.z, null);
            }
            if (entry.order != null) {
                entry.order.targetX = target.x;
                entry.order.targetZ = target.z;
            }
        }
        if (flight.isParked(aircraft) && mission.getState() != MissionState.RETURNING) {
            // A terminal payload launch is irreversible. Native PARKED/attack
            // completion is not effect confirmation and must not trigger a
            // replacement route or a second launch.
            if (mission.getState() == MissionState.KAMIKADZE_TARGET
                    && mission.isKamikazePayloadLaunched()) {
                return false;
            }
            if (mission.isAttack() && profile(aircraft).isReusable()
                    && mission.getState() == MissionState.ATTACK_TARGET
                    && flight.isAttackComplete(aircraft)) {
                mission.transitionTo(MissionState.APPROACHING, tick);
                mission.transitionTo(MissionState.ON_TARGET, tick);
                mission.transitionTo(MissionState.SCANNING, tick);
                return true;
            }
            if (mission.isAttack() && !profile(aircraft).isReusable() && target != null) {
                if (withinMissionExecutionRange(aircraft, target, mission)
                        && terminalGeometrySatisfied(aircraft, target, mission)
                        && !mission.isKamikazePayloadLaunched()
                        && flight.fireSelfDestructWeapon(aircraft)) {
                    if (armKamikazeTerminalState(mission, target, tick)) {
                        fail(world, mission, "KAMIKAZE_TERMINAL_STATE_REJECTED", tick);
                        return true;
                    }
                    mission.markKamikazePayloadLaunched(tick);
                    confirmKamikazeEffect(world, mission, tick);
                    RdpUavDebug.event("TerminalGuidance", "PAYLOAD_LAUNCH_ACCEPTED",
                            "mission", mission.getMissionId(),
                            "aircraft", mission.getAircraftId(),
                            "target", mission.getTargetId(), "tick", tick);
                    return true;
                }
                flight.release(aircraft);
                double routeY = terminalRouteAltitude(aircraft, target);
                if (flight.dispatch(aircraft, target.x, routeY, target.z,
                        mission.getObservationDistance(), 0, true,
                        target.entity == null ? null : target.entity.getUniqueID())) {
                    mission.beginRouteProgressWindow(tick);
                    mission.transitionTo(MissionState.REPLAN, tick);
                    return true;
                }
            }
            if (withinMissionExecutionRange(aircraft, target, mission)) {
                if (mission.getState() == MissionState.TARGET_LOCKED) {
                    mission.transitionTo(MissionState.APPROACHING, tick);
                    return true;
                }
                if (mission.getState() == MissionState.APPROACHING) {
                    mission.transitionTo(MissionState.ON_TARGET, tick);
                    mission.transitionTo(MissionState.SCANNING, tick);
                    return true;
                }
            }
            if (mission.isTerminal()) return false;
            defer(world, mission, "WINGMAN_TERMINATED_BEFORE_RETURN",
                    MissionState.EXECUTION_STALLED, tick);
            return true;
        }
        if (flight.isReturning(aircraft) && mission.getState() != MissionState.RETURNING) {
            if (mission.getState() == MissionState.ATTACK_TARGET
                    || mission.getState() == MissionState.REPORTING) {
                mission.transitionTo(MissionState.RETURNING, tick);
            } else {
                defer(world, mission, "WINGMAN_RTB_BEFORE_REPORT",
                        MissionState.RECOVERING, tick);
            }
            return true;
        }

        WingmanEntry routeEntry = flight.getEntry(aircraft);
        double currentRouteProgress = routeEntry == null || routeEntry.mission == null
                ? mission.getRouteProgress() : Math.max(0.0D, routeEntry.missionIndex);
        double currentDistanceToTarget = target == null ? Double.NaN : targetDistance(aircraft, target);
        double currentDistanceToWaypoint = routeEntry == null
                || !Double.isFinite(routeEntry.autoTargetX)
                || !Double.isFinite(routeEntry.autoTargetY)
                || !Double.isFinite(routeEntry.autoTargetZ)
                ? Double.NaN : Math.sqrt(
                        Math.pow(aircraft.posX - routeEntry.autoTargetX, 2.0D)
                                + Math.pow(aircraft.posY - routeEntry.autoTargetY, 2.0D)
                                + Math.pow(aircraft.posZ - routeEntry.autoTargetZ, 2.0D));
        boolean recoveryChanged = mission.recordObservedProgress(tick,
                mission.getRouteProgress(),
                currentRouteProgress,
                currentDistanceToTarget,
                currentDistanceToWaypoint,
                progressExpected(mission.getState()));
        if (recoveryChanged) RDPMissionWorldData.get(world).markDirty();
        if (mission.isTerminal()) return true;

        switch (mission.getState()) {
        case SEARCHING:
            UavVehicleProfile vehicleProfile = profile(aircraft);
            if (vehicleProfile.supportsLongRangeLock()) {
                assert target != null;
                if (target.entity != null
                        && targetDistance(aircraft, target) <= vehicleProfile.getLockRange()) {
                    mission.transitionTo(MissionState.TARGET_ACQUIRED, tick);
                    mission.lockTarget(target.entity.getUniqueID(), tick);
                    return true;
                }
            }
            if (!atTarget(aircraft, target, mission)
                    || !flight.hasReachedRoutePoint(aircraft)) return false;
            mission.transitionTo(MissionState.TARGET_ACQUIRED, tick);
            if (target.entity == null) mission.lockPoint(tick);
            else mission.lockTarget(target.entity.getUniqueID(), tick);
            return true;
        case TARGET_LOCKED:
                MissionSafety.RouteDecision approach = evaluateApproach(world, aircraft, target, mission);
                if (approach == MissionSafety.RouteDecision.HOLD_AND_REEVALUATE) {
                    RdpUavDebug.debug("Lifecycle",
                            "mission {} hold-and-reevaluate aircraft={} target={} route={} distance={}",
                            mission.getMissionId(), aircraft.getUniqueID(), formatTarget(target),
                            approach, target == null ? -1.0D : targetDistance(aircraft, target));
                    return false;
                }
                refreshRoute(aircraft, target, mission, approach, tick);
                if (!flight.hasReachedRoutePoint(aircraft)) return false;
                if (!withinMissionExecutionRange(aircraft, target, mission)) {
                    return false;
                }
                if (approach != MissionSafety.RouteDecision.DIRECT_INTERCEPT) {
                    mission.transitionTo(MissionState.APPROACHING, tick);
                    return true;
                }
                UUID pilotTarget = KamikazePilotOverride.targetFor(aircraft.getUniqueID());
                if (mission.isAttack() && flight.hasSelfDestructWeaponWithAmmo(aircraft) && (!profile(aircraft).isReusable() || mission.isDestructiveAuthorized()) && (pilotTarget == null || pilotTarget.equals(
                        target.entity == null ? null : target.entity.getUniqueID()))) {
                    if (flight.armKamikaze(aircraft, target.x, target.y, target.z,
                            mission.getObservationDistance(),
                            target.entity == null ? null : target.entity.getUniqueID())) {
                        fail(world, mission, "AI_KAMIKAZE_ARM_REJECTED", tick);
                    } else {
                        mission.transitionTo(MissionState.KAMIKADZE_TARGET, tick);
                    }
                    return true;
                }
                if (mission.isAttack()) {
                    GuidedStrikeObjective guidedObjective = target.entity == null
                            ? GuidedStrikeObjective.square(mission.getMissionId(),
                            world.provider.getDimension(), target.x, target.y, target.z, tick)
                            : GuidedStrikeObjective.entity(mission.getMissionId(),
                            target.entity.getUniqueID(), world.provider.getDimension(),
                            target.x, target.y, target.z, tick);
                    guidedObjective.authorize();
                    guidedObjective.beginTracking();
                    boolean directReusableLaunch = profile(aircraft).isReusable();
                    GuidedWeaponDecision guided = directReusableLaunch
                            ? guidedWeapons.armDirect(world, aircraft, guidedObjective,
                            aircraftSpeed(aircraft), profile(aircraft).getAttackEnvelope(), true,
                            weaponPriority(mission, aircraft))
                            : guidedWeapons.arm(world, aircraft, guidedObjective,
                            aircraftSpeed(aircraft), profile(aircraft).getAttackEnvelope(), true,
                            weaponPriority(mission, aircraft));
                    if (guided.isAccepted()) {
                        guidedObjective.release();
                        mission.transitionTo(MissionState.ATTACK_TARGET, tick);
                        return true;
                    }
                    if (!"NO_GUIDED_WEAPON".equals(guided.getReason())) {
                        RdpUavDebug.debug("Lifecycle",
                                "mission {} guided attack decision={} aircraft={} target={}",
                                mission.getMissionId(), guided.getReason(), aircraft.getUniqueID(),
                                formatTarget(target));
                        if (guided.getReason().startsWith("GUIDED_HOLD_")
                                || guided.getReason().startsWith("GUIDED_WAIT_")) {
                            defer(world, mission, guided.getReason(),
                                    guidanceRecoveryState(guided.getReason()), tick);
                            return true;
                        }
                        if (isPermanentGuidanceFailure(guided.getReason())) {
                            fail(world, mission, guided.getReason(), tick);
                            return true;
                        }
                        defer(world, mission, guided.getReason(),
                                guidanceRecoveryState(guided.getReason()), tick);
                        return true;
                    }
                    if (profile(aircraft).isReusable()
                            && mission.getMissionType() == MissionType.SQUARE_STRIKE) {
                        fail(world, mission, "REUSABLE_UAV_GUIDED_WEAPON_REQUIRED", tick);
                        return true;
                    }
                    if (!profile(aircraft).isReusable()
                            && mission.getMissionType() == MissionType.SQUARE_STRIKE) {
                        net.vas.rdp.uav.flight.SquareStrikePlan squarePlan =
                                new net.vas.rdp.uav.flight.SquareStrikePlan(
                                        mission.getTargetSpec().getX(),
                                        target.y + Math.max(
                                                net.vas.rdp.uav.flight.SquareStrikeConfig.minimumAltitude,
                                                net.vas.rdp.uav.flight.SquareStrikeConfig.terminalAltitudeOffset),
                                        mission.getTargetSpec().getZ(),
                                        mission.getSquareWidth(),
                                        mission.getSquareDepth(),
                                        net.vas.rdp.uav.flight.SquareStrikeConfig.headingDegrees,
                                        Math.max(1.0D, Math.min(mission.getSquareDepth(),
                                                mission.getSquareDepth()
                                                        * net.vas.rdp.uav.flight.SquareStrikeConfig.passSpacingFactor)),
                                        profile(aircraft).getAttackEnvelope(),
                                        Math.max(1, (int) Math.ceil(mission.getSquareDepth()
                                                / Math.max(1.0D, mission.getSquareDepth()
                                                * net.vas.rdp.uav.flight.SquareStrikeConfig.passSpacingFactor))),
                                        target.y);
                        if (!flight.armSquareStrike(aircraft, squarePlan,
                                mission.getTargetId())) {
                            fail(world, mission, "ONE_WAY_SQUARE_TERMINAL_PAYLOAD_REQUIRED", tick);
                        } else {
                            mission.transitionTo(MissionState.ATTACK_TARGET, tick);
                        }
                        return true;
                    }
                    if (!flight.armAttack(aircraft, target.x, target.y, target.z,
                            profile(aircraft).getAttackEnvelope(), mission.getTargetId(),
                            weaponPriority(mission, aircraft))) {
                        defer(world, mission, "WINGMAN_ATTACK_ARM_REJECTED",
                                MissionState.EXECUTION_STALLED, tick);
                    } else {
                        mission.transitionTo(MissionState.ATTACK_TARGET, tick);
                    }
                    return true;
                }
                if (withinMissionExecutionRange(aircraft, target, mission)) {
                    mission.transitionTo(MissionState.APPROACHING, tick);
                    mission.transitionTo(MissionState.ON_TARGET, tick);
                    mission.transitionTo(MissionState.SCANNING, tick);
                    return true;
                }
                return false;
            case ATTACK_TARGET:
                // No damage or self-destruct result is inferred.  WingMan's
                // attack node must complete before scan/report/RTB can begin.
                if (flight.isReturning(aircraft)) {
                    mission.transitionTo(MissionState.RETURNING, tick);
                    return true;
                }
                if (flight.isAttackComplete(aircraft)) {
                    if (mission.getMissionType() == MissionType.SQUARE_STRIKE
                            && !profile(aircraft).isReusable()) {
                        if ("SELF_DESTRUCT".equalsIgnoreCase(
                                profile(aircraft).getTerminalPayloadBehavior())
                                && terminalGeometrySatisfied(aircraft, target, mission)
                                && !mission.isKamikazePayloadLaunched()
                                && flight.fireSelfDestructWeapon(aircraft)) {
                            if (armKamikazeTerminalState(mission, target, tick)) {
                                fail(world, mission, "KAMIKAZE_TERMINAL_STATE_REJECTED", tick);
                                return true;
                            }
                            mission.markKamikazePayloadLaunched(tick);
                            confirmKamikazeEffect(world, mission, tick);
                            RdpUavDebug.event("TerminalGuidance", "PAYLOAD_LAUNCH_ACCEPTED",
                                    "mission", mission.getMissionId(),
                                    "aircraft", mission.getAircraftId(),
                                    "target", mission.getTargetId(), "tick", tick);
                            return true;
                        }

                        fail(world, mission, "ONE_WAY_SQUARE_TERMINAL_PAYLOAD_UNAVAILABLE", tick);
                        return true;
                    }
                    mission.transitionTo(MissionState.APPROACHING, tick);
                    mission.transitionTo(MissionState.ON_TARGET, tick);
                    mission.transitionTo(MissionState.SCANNING, tick);
                    return true;
                }
                return false;
            case KAMIKADZE_TARGET:
                if (flight.isReturning(aircraft)) {
                    fail(world, mission, mission.isKamikazePayloadLaunched()
                            ? "KAMIKAZE_RETURNED_WITHOUT_EFFECT_CONFIRMATION"
                            : "KAMIKAZE_RETURNED_BEFORE_PAYLOAD_LAUNCH", tick);
                    return true;
                }
                if (flight.isAttackComplete(aircraft)) {
                    if (mission.isKamikazePayloadLaunched()) {
                        RdpUavDebug.debug("Lifecycle",
                                "mission {} native attack complete without effect confirmation",
                                mission.getMissionId());
                    }
                    return true;
                }
                return false;
            case APPROACHING:
                MissionSafety.RouteDecision approachRoute =
                        evaluateApproach(world, aircraft, target, mission);
                if (approachRoute == MissionSafety.RouteDecision.HOLD_AND_REEVALUATE) return false;
                refreshRoute(aircraft, target, mission, approachRoute, tick);
                if (atTarget(aircraft, target, mission)
                        && flight.hasReachedRoutePoint(aircraft)) {
                    mission.transitionTo(MissionState.ON_TARGET, tick);
                    if (approachRoute == MissionSafety.RouteDecision.OFFSET_ORBIT
                            || approachRoute == MissionSafety.RouteDecision.SAFE_SIDE_APPROACH) {
                        mission.transitionTo(MissionState.ORBITING, tick);
                    } else {
                        mission.transitionTo(MissionState.SCANNING, tick);
                    }
                    return true;
                }
                return false;
            case ON_TARGET:
            case ORBITING:
                if (!flight.hasReachedRoutePoint(aircraft)) return false;
                mission.transitionTo(MissionState.SCANNING, tick);
                return true;
            case SCANNING:
                if (mission.isDeepScan()) {
                    mission.transitionTo(MissionState.DEEP_SCANNING, tick);
                } else {
                    persistReport(world, mission, target, tick);
                    mission.transitionTo(MissionState.REPORTING, tick);
                }
                return true;
            case DEEP_SCANNING:
                persistReport(world, mission, target, tick);
                mission.transitionTo(MissionState.REPORTING, tick);
                return true;
            case REPORTING:
                // Reporting ends the task but does not silently land or RTB.
                // The operator must explicitly request return-to-base.
                UavVehicleProfile stationProfile = profile(aircraft);
                double centerX = target == null ? aircraft.posX : target.x;
                double centerZ = target == null ? aircraft.posZ : target.z;
                TerrainRoutePlanner.Plan stationAltitude = TerrainRoutePlanner.planTransit(
                        world, perception, aircraft.posX, aircraft.posY, aircraft.posZ,
                        aircraftSpeed(aircraft), centerX, centerZ, stationProfile, tick);
                if (!stationAltitude.isSafe()
                        || !flight.enterStationHold(aircraft, centerX,
                        stationAltitude.getY(), centerZ, stationProfile.getStationRadius())) {
                    RdpUavDebug.event("MissionRuntime", "STATION_HOLD_REJECTED",
                            "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                            "tick", tick, "terrain", stationAltitude.getReason(),
                            "radius", stationProfile.getStationRadius());
                    return false;
                }
                mission.transitionTo(MissionState.HOLDING, tick);
                return true;
            case RETURNING:
                if (flight.isParked(aircraft)) {
                    mission.transitionTo(MissionState.LANDING, tick);
                    mission.transitionTo(MissionState.PARKING, tick);
                    mission.complete(tick);
                    return true;
                }
                return false;
            default:
                return false;
        }
    }

    private boolean armKamikazeTerminalState(RDPMission mission, Target target, long tick) {
        if (mission == null || target == null) return true;
        switch (mission.getState()) {
        case SEARCHING:
            mission.transitionTo(MissionState.TARGET_ACQUIRED, tick);
            if (target.entity == null) mission.lockPoint(tick);
            else mission.lockTarget(target.entity.getUniqueID(), tick);
            mission.transitionTo(MissionState.KAMIKADZE_TARGET, tick);
            return false;
        case TARGET_ACQUIRED:
            if (target.entity == null) mission.lockPoint(tick);
            else mission.lockTarget(target.entity.getUniqueID(), tick);
            mission.transitionTo(MissionState.KAMIKADZE_TARGET, tick);
            return false;
        case TARGET_LOCKED:
            case ATTACK_TARGET:
                mission.transitionTo(MissionState.KAMIKADZE_TARGET, tick);
            return false;
            case KAMIKADZE_TARGET:
            return false;
        default:
            return true;
        }
    }

    /**
     * The native payload adapter returns true only after MCH_Explosion has
     * synchronously produced an ExplosionResult and the aircraft has been
     * destructed. Record that effect before the next world tick can mistake
     * the intentionally removed aircraft for an unconfirmed loss. The result
     * does not claim that a particular target entity was hit or destroyed.
     */
    private void confirmKamikazeEffect(World world, RDPMission mission, long tick) {
        mission.confirmKamikazeEffect(tick);
        RdpUavDebug.event("TerminalGuidance", "PAYLOAD_EFFECT_CONFIRMED",
                "mission", mission.getMissionId(),
                "aircraft", mission.getAircraftId(),
                "target", mission.getTargetId(),
                "tick", tick,
                "effect", "MCHELI_EXPLOSION_CREATED",
                "targetHitInferred", false);
        RDPMissionWorldData.get(world).markDirty();
    }

    private void persistReport(World world, RDPMission mission, Target target, long tick) {
        if (mission.getReportId() != null || target == null) return;
        UUID targetId = mission.getTargetId() == null ? mission.getMissionId() : mission.getTargetId();
        net.minecraft.util.ResourceLocation key = target.entity == null
                ? null : EntityList.getKey(target.entity);
        String registryId = key == null ? "rdpuav:unknown" : key.toString();
        String reportId = mission.getMissionId().toString();
        RDPScanReport report = new RDPScanReport(reportId, mission.getMissionId(), targetId,
                registryId, world.provider.getDimension(), target.x, target.y, target.z,
                mission.isDeepScan(), mission.getTargetPriority(),
                Math.max(0L, tick - mission.getCreatedTick()), tick);
        RDPScanReportRepository.get(world).put(report);
        mission.setReportId(reportId);
    }

    private Target reacquire(World world, MCH_EntityAircraft aircraft, RDPMission mission, long tick) {
        Entity current = targets.findLoaded(world, mission.getTargetId());
        UavVehicleProfile vehicleProfile = profile(aircraft);
        if (current != null && targetDistance(aircraft, Target.entity(current))
                <= vehicleProfile.getLockRange()
                && canMissionUseTarget(world, mission, current.getUniqueID())) {
            targets.observe(world, current, targetDistance(aircraft, Target.entity(current)),
                    tick, ContactLifecycle.TRACKING);
            projectTargetLock(world, mission, current, tick);
            return Target.entity(current);
        }
        if (mission.getTargetId() != null) {
            targets.markLost(mission.getTargetId(), tick);
            // A tracked identity may be reacquired, but it must never be
            // replaced by an unrelated nearby entity after disappearing.
            return null;
        }
        List<TargetResolver.EntityCandidate> candidates = targets.find(world, aircraft.posX,
                aircraft.posY, aircraft.posZ,
                vehicleProfile.getDetectionRange(),
                mission.getTargetSpec());
        if (candidates.isEmpty()) return null;
        Entity reacquired = null;
        TargetResolver.EntityCandidate selectedCandidate = null;
        for (TargetResolver.EntityCandidate candidate : candidates) {
            if (canMissionUseTarget(world, mission, candidate.getEntity().getUniqueID())) {
                reacquired = candidate.getEntity();
                selectedCandidate = candidate;
                break;
            }
        }
        if (reacquired == null || selectedCandidate == null) return null;
        targets.observe(world, reacquired,
                Math.sqrt(selectedCandidate.getDistanceSquared()), tick, ContactLifecycle.SELECTABLE);
        if (mission.getTargetId() == null) mission.reacquireTarget(reacquired.getUniqueID(), tick);
        else if (!mission.getTargetId().equals(reacquired.getUniqueID())) {
            // Manual and automatic searches may recover a moved entity, but
            // never silently substitute another entity after a lock.
            if (mission.getTargetSelectionMode() == TargetSelectionMode.MANUAL) return null;
            mission.reacquireTarget(reacquired.getUniqueID(), tick);
        }
        projectTargetLock(world, mission, reacquired, tick);
        return Target.entity(reacquired);
    }

    private Target locateTarget(World world, MCH_EntityAircraft aircraft, RDPMission mission) {
        if (mission.getTargetSelectionMode() == TargetSelectionMode.POINT) {
            return resolvePointTarget(world, mission.getTargetSpec().getX(),
                    mission.getTargetSpec().getY(), mission.getTargetSpec().getZ());
        }
        UUID sharedTargetId = net.vas.rdp.uav.RDPUavMod.swarms()
                .sharedTargetId(world, mission);
        if (sharedTargetId != null && mission.getTargetId() == null) {
            Entity sharedTarget = targets.findLoaded(world, sharedTargetId);
            if (sharedTarget == null || !TargetPolicy.builder()
                    .include(mission.getTargetPolicy().getInclude().toArray(new String[0]))
                    .require(mission.getTargetPolicy().getRequire().toArray(new String[0]))
                    .exclude(mission.getTargetPolicy().getExclude().toArray(new String[0]))
                    .rejectDeeplyEmbedded(mission.getTargetPolicy().isRejectEmbedded())
                    .allowHostileVehicles(mission.getTargetPolicy().isAllowVehicleTargets())
                    .withMinimumConfidence(mission.getTargetPolicy().getMinimumConfidence())
                    .evaluate(world, sharedTarget, null).isAccepted()
                    || !canMissionUseTarget(world, mission, sharedTargetId)) {
                return null;
            }
            targets.observe(world, sharedTarget, aircraft.getDistance(sharedTarget),
                    world.getTotalWorldTime(), ContactLifecycle.SELECTED);
            mission.reacquireTarget(sharedTargetId, world.getTotalWorldTime());
            projectTargetLock(world, mission, sharedTarget, world.getTotalWorldTime());
            return Target.entity(sharedTarget);
        }
        Entity current = targets.findLoaded(world, mission.getTargetId());
        // Once an operator has locked an entity UUID, disappearance must
        // remain TARGET_LOST/WATING_FOR_TARGET until that same UUID returns.
        // Never substitute another entity sharing the original registry id.
        if (current == null && mission.getTargetId() == null
                && mission.getTargetSelectionMode() == TargetSelectionMode.MANUAL) {
            current = targets.findLoadedByRegistryId(world, mission.getTargetSpec().getRegistryId());
        }
        if (current != null && !canMissionUseTarget(world, mission, current.getUniqueID())) {
            if (mission.getTargetId() != null
                    || mission.getTargetSelectionMode() != TargetSelectionMode.MANUAL) return null;
            current = null;
        }
        if (current != null && !net.vas.rdp.uav.target.TargetPolicy.builder()
                .include(mission.getTargetPolicy().getInclude().toArray(new String[0]))
                .require(mission.getTargetPolicy().getRequire().toArray(new String[0]))
                .exclude(mission.getTargetPolicy().getExclude().toArray(new String[0]))
                .rejectDeeplyEmbedded(mission.getTargetPolicy().isRejectEmbedded())
                .allowHostileVehicles(mission.getTargetPolicy().isAllowVehicleTargets())
                .withMinimumConfidence(mission.getTargetPolicy().getMinimumConfidence())
                .evaluate(world, current, null).isAccepted()) {
            return null;
        }
        if (current != null && (mission.getTargetSelectionMode() == TargetSelectionMode.MANUAL
                || aircraft.getDistanceSq(current) <=
                profile(aircraft).getDetectionRange() * profile(aircraft).getDetectionRange())) {
            targets.observe(world, current, aircraft.getDistance(current),
                    world.getTotalWorldTime(), ContactLifecycle.SELECTED);
            projectTargetLock(world, mission, current, world.getTotalWorldTime());
            return Target.entity(current);
        }
        if (current != null) return null;
        List<TargetResolver.EntityCandidate> candidates = targets.find(world, aircraft.posX,
                aircraft.posY, aircraft.posZ,
                profile(aircraft).getDetectionRange(),
                mission.getTargetSpec(), null, mission.getTargetPolicy());
        if (candidates.isEmpty()) return null;
        Entity selected = null;
        TargetResolver.EntityCandidate selectedCandidate = null;
        for (TargetResolver.EntityCandidate candidate : candidates) {
            if (canMissionUseTarget(world, mission, candidate.getEntity().getUniqueID())) {
                selected = candidate.getEntity();
                selectedCandidate = candidate;
                break;
            }
        }
        if (selected == null || selectedCandidate == null) return null;
        targets.observe(world, selected,
                Math.sqrt(selectedCandidate.getDistanceSquared()), world.getTotalWorldTime(),
                ContactLifecycle.SELECTABLE);
        return Target.entity(selected);
    }

    private boolean canMissionUseTarget(World world, RDPMission mission, UUID targetId) {
        return mission.getSwarmId() == null
                || net.vas.rdp.uav.RDPUavMod.swarms()
                        .canMissionUseTarget(world, mission, targetId);
    }

    private void projectTargetLock(World world, RDPMission mission, Entity target, long tick) {
        if (world == null || mission == null || target == null || mission.getTargetId() == null
                || !mission.getTargetId().equals(target.getUniqueID())) return;
        net.minecraft.util.ResourceLocation key = EntityList.getKey(target);
        mission.updateTargetLock(key == null ? "rdpuav:unknown" : key.toString(),
                world.provider.getDimension(), target.posX, target.posY, target.posZ, tick);
        net.vas.rdp.uav.RDPUavMod.swarms().publishValidatedObservation(world,
                mission.getAircraftId(), target.getUniqueID(), world.provider.getDimension(),
                target.posX, target.posY, target.posZ, tick);
    }

    public ContactSnapshot contact(UUID targetId) {
        return targets.get(targetId);
    }

    @SuppressWarnings("unused")
    public ContactSnapshot operatorContact(MCH_EntityAircraft aircraft) {
        return aircraft == null ? null : targets.get(operatorContacts.get(aircraft.getUniqueID()));
    }

    public boolean cycleContact(World world, MCH_EntityAircraft aircraft, boolean next) {
        return cycleContact(world, aircraft, null, next);
    }

    public boolean cycleContact(World world, MCH_EntityAircraft aircraft, EntityPlayer operator,
                                boolean next) {
        if (world == null || aircraft == null) return false;
        for (RDPMission mission : RDPMissionWorldData.get(world).getRepository().snapshot()) {
            if (!mission.getAircraftId().equals(aircraft.getUniqueID()) || mission.isTerminal()) continue;
            UUID current = operatorContacts.get(aircraft.getUniqueID());
            List<ContactSnapshot> available = new java.util.ArrayList<>(
                    targets.selectable());
            if (available.isEmpty()) return false;
            int start = -1;
            for (int i = 0; i < available.size(); i++) {
                if (available.get(i).getEntityId().equals(current)) { start = i; break; }
            }
            int offset = next ? 1 : available.size() - 1;
            for (int i = 0; i < available.size(); i++) {
                ContactSnapshot candidate = available.get((start < 0 ? 0 : start + offset + i)
                        % available.size());
                Entity entity = targets.findLoaded(world, candidate.getEntityId());
                if (entity != null && net.vas.rdp.uav.target.TargetPolicy
                        .isSelectableContact(world, entity, operator)) {
                    targets.select(candidate.getEntityId());
                    operatorContacts.put(aircraft.getUniqueID(), candidate.getEntityId());
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public boolean clearContact(World world, MCH_EntityAircraft aircraft) {
        if (world == null || aircraft == null) return false;
        for (RDPMission mission : RDPMissionWorldData.get(world).getRepository().snapshot()) {
            if (mission.getAircraftId().equals(aircraft.getUniqueID()) && !mission.isTerminal()) {
                operatorContacts.remove(aircraft.getUniqueID());
                return true;
            }
        }
        return false;
    }

    private MissionSafety.RouteDecision evaluateApproach(World world, MCH_EntityAircraft aircraft,
                                                        Target target, RDPMission mission) {
        if (world == null || aircraft == null || target == null) {
            return MissionSafety.RouteDecision.HOLD_AND_REEVALUATE;
        }
        /*
         * One-way platforms are terminal strike vehicles, not observation
         * aircraft. Never let corridor safety convert their terminal route
         * into an offset orbit or a reusable-UAV hold.
         */
        if (mission.isAttack() && !profile(aircraft).isReusable()) {
            return MissionSafety.RouteDecision.DIRECT_INTERCEPT;
        }

        double dx = target.x - aircraft.posX;
        double dy = target.y - aircraft.posY;
        double dz = target.z - aircraft.posZ;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (distance <= 1.0D) {
            return MissionSafety.RouteDecision.HOLD_AND_REEVALUATE;
        }

        double altitudeDelta = Math.abs(dy);
        double observationDistance = mission.getObservationDistance();
        if (!routeCorridorLoaded(world, aircraft.posX, aircraft.posY, aircraft.posZ,
                target.x, target.y, target.z, world.getTotalWorldTime())) {
            RdpUavDebug.debug("Lifecycle",
                    "terminal approach held because route corridor is not loaded: mission={} aircraft={}",
                    mission.getMissionId(), aircraft.getUniqueID());
            return MissionSafety.RouteDecision.HOLD_AND_REEVALUATE;
        }
        Vec3d start = new Vec3d(aircraft.posX, aircraft.posY + aircraft.getEyeHeight(), aircraft.posZ);
        Vec3d end = new Vec3d(target.x, target.y + 1.0D, target.z);
        RayTraceResult hit = world.rayTraceBlocks(start, end, false, true, false);
        boolean lineOfSightBlocked = hit != null && hit.typeOfHit == RayTraceResult.Type.BLOCK;
        boolean hostileExposure = corridorHasHostileExposure(world, aircraft, target, start, end);
        boolean fuelReady = !flight.isFuelInsufficientForMission(aircraft);
        boolean returnViable = true;
        TerminalCommitPolicy.Decision terminal = TerminalCommitPolicy.evaluate(
                distance, altitudeDelta, lineOfSightBlocked, lineOfSightBlocked,
                hostileExposure, fuelReady, returnViable, observationDistance,
                Math.max(8.0D, observationDistance * 0.5D));

        if (terminal.getState() == TerminalCommitPolicy.DecisionState.HOLD
                || terminal.getState() == TerminalCommitPolicy.DecisionState.ABORT) {
            return MissionSafety.RouteDecision.HOLD_AND_REEVALUATE;
        }
        if (terminal.getCorridor() != null) {
            MissionSafety.RouteDecision route = terminal.getCorridor().getRouteDecision();
            if (route != null) return route;
        }
        return MissionSafety.decideRoute(distance, altitudeDelta, lineOfSightBlocked, observationDistance);
    }

    private static boolean corridorHasHostileExposure(World world,
                                                       MCH_EntityAircraft aircraft,
                                                       Target target,
                                                       Vec3d start,
                                                       Vec3d end) {
        if (world == null || aircraft == null || target == null || start == null || end == null) {
            return true;
        }
        AxisAlignedBB corridor = new AxisAlignedBB(start, end).grow(4.0D);
        for (Entity entity : world.getEntitiesWithinAABB(Entity.class, corridor)) {
            if (entity == null || entity.isDead || entity == aircraft
                    || target.entity == entity) continue;
            ResourceLocation key = EntityList.getKey(entity);
            if (TargetClassifier.isHostileCandidate(key == null ? "" : key.toString())
                    || TargetClassifier.isHostileVehicle(entity)) {
                return true;
            }
        }
        return false;
    }

    private boolean routeCorridorLoaded(World world,
                                        double startX, double startY, double startZ,
                                        double endX, double endY, double endZ,
                                        long tick) {
        if (world == null || tick < 0L) return false;
        double dx = endX - startX;
        double dy = endY - startY;
        double dz = endZ - startZ;
        double distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (!Double.isFinite(distance)) return false;
        int samples = Math.max(1, (int) Math.ceil(distance / 8.0D));
        for (int i = 0; i <= samples; i++) {
            double fraction = (double) i / (double) samples;
            BlockPos sample = new BlockPos(
                    (int) Math.floor(startX + dx * fraction),
                    (int) Math.floor(startY + dy * fraction),
                    (int) Math.floor(startZ + dz * fraction));
            if (perception.observeChunk(world, sample.getX() >> 4, sample.getZ() >> 4, tick)
                    .getState() != ChunkState.LOADED) return false;
        }
        return true;
    }

    private static boolean progressExpected(MissionState state) {
        return state != MissionState.ORBITING
                && state != MissionState.ON_TARGET
                && state != MissionState.SCANNING
                && state != MissionState.DEEP_SCANNING
                && state != MissionState.REPORTING
                && state != MissionState.HOLDING;
    }

    private void refreshRoute(MCH_EntityAircraft aircraft, Target target, RDPMission mission,
                              MissionSafety.RouteDecision decision, long tick) {
        if (target == null || decision == MissionSafety.RouteDecision.HOLD_AND_REEVALUATE) return;
        if (mission.getControlOwner() == ControlOwner.TERMINAL_GUIDANCE) return;
        UUID aircraftId = aircraft.getUniqueID();
        RouteRefresh previous = routeRefreshes.get(aircraftId);
        boolean orbit = !mission.isAttack()
                && (decision == MissionSafety.RouteDecision.OFFSET_ORBIT
                || decision == MissionSafety.RouteDecision.SAFE_SIDE_APPROACH);
        boolean moved = previous == null
                || previous.distanceSquared(target.x, target.y, target.z) >= 16.0D;
        boolean due = previous == null
                || (tick - previous.tick >= 10L && flight.hasReachedRoutePoint(aircraft));
        if (!moved && !due) return;
        double guidanceY = terminalRouteAltitude(aircraft, target);
        boolean refreshed = decision == MissionSafety.RouteDecision.OFFSET_ORBIT
                || decision == MissionSafety.RouteDecision.SAFE_SIDE_APPROACH
                ? flight.refreshBoundedDetour(aircraft, target.x, guidanceY, target.z,
                mission.getObservationDistance(), mission.getTargetId())
                : flight.refreshObservationRoute(aircraft, target.x, guidanceY, target.z,
                mission.getObservationDistance(), false, mission.getTargetId());
        if (refreshed) {
            routeRefreshes.put(aircraftId, new RouteRefresh(tick, target.x, guidanceY, target.z));
        }

        WingmanEntry entry = flight.getEntry(aircraft);
        RdpUavDebug.event("MissionRuntime", "ROUTE_REFRESH",
                "mission", mission.getMissionId(), "aircraft", aircraftId, "tick", tick,
                "decision", decision, "accepted", refreshed,
                "routeSize", entry == null || entry.mission == null ? 0 : entry.mission.size(),
                "missionIndex", entry == null ? -1 : entry.missionIndex,
                "nodeTimer", entry == null ? -1 : entry.missionNodeTimer,
                "target", formatTarget(target));
    }

    private void dispatchPatrol(World world, RDPMission mission,
                                MCH_EntityAircraft aircraft, long tick) {
        PatrolRoutePlanner.Plan plan = PatrolRoutePlanner.plan(world, aircraft,
                mission.getPatrolRoute(), profile(aircraft), tick);
        if (!plan.isAccepted()) {
            if (plan.getReason().contains("UNLOADED") || plan.getReason().contains("UNKNOWN")) {
                defer(world, mission, plan.getReason(), MissionState.WAITING_FOR_WORLD, tick);
            } else {
                fail(world, mission, "PATROL_ROUTE_REJECTED_" + plan.getReason(), tick);
            }
            return;
        }
        if (!MissionMovementAuthority.claimControl(mission, aircraft.getUniqueID(), tick)) {
            defer(world, mission, "PATROL_CONTROL_LEASE_REJECTED",
                    MissionState.EXECUTION_STALLED, tick);
            return;
        }
        if (!flight.dispatchPatrolRoute(aircraft, plan.getWaypoints())) {
            defer(world, mission, "PATROL_WINGMAN_DISPATCH_REJECTED",
                    MissionState.EXECUTION_STALLED, tick);
            return;
        }
        if (mission.getState() == MissionState.PLANNED) {
            mission.transitionTo(MissionState.DISPATCHED, tick);
            mission.transitionTo(MissionState.TAKEOFF, tick);
            mission.transitionTo(MissionState.CRUISE, tick);
            mission.transitionTo(MissionState.SEARCHING, tick);
        } else if (mission.getState() != MissionState.SEARCHING) {
            if (!mission.getState().canTransitionTo(MissionState.SEARCHING)) {
                fail(world, mission, "PATROL_REPLAN_STATE_REJECTED", tick);
                return;
            }
            mission.transitionTo(MissionState.SEARCHING, tick, "PATROL_ROUTE_RESTORED");
        }
        mission.beginRouteProgressWindow(tick);
        mission.setQueued(false);
        RdpUavDebug.event("MissionRuntime", "PATROL_ROUTE_DISPATCH",
                "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                "waypoints", plan.getWaypoints().size(), "tick", tick, "accepted", true);
        RDPMissionWorldData.get(world).markDirty();
    }

    private boolean updatePatrol(World world, RDPMission mission,
                                 MCH_EntityAircraft aircraft, long tick) {
        if (mission.getState() == MissionState.RETURNING) {
            if (!flight.isParked(aircraft)) return false;
            mission.transitionTo(MissionState.LANDING, tick);
            mission.transitionTo(MissionState.PARKING, tick);
            mission.complete(tick);
            flight.release(aircraft);
            manager.release(mission);
            RDPMissionWorldData.get(world).markDirty();
            return true;
        }
        if (flight.isReturning(aircraft)) {
            if (mission.getState() != MissionState.RETURNING) {
                if (!mission.getState().canTransitionTo(MissionState.RETURNING)) {
                    fail(world, mission, "PATROL_RETURN_STATE_REJECTED", tick);
                    return true;
                }
                mission.transitionTo(MissionState.RETURNING, tick, "PATROL_ROUTE_COMPLETE");
                RDPMissionWorldData.get(world).markDirty();
            }
            return false;
        }
        WingmanEntry entry = flight.getEntry(aircraft);
        if (entry == null || entry.mission == null || entry.mission.isEmpty()) {
            dispatchPatrol(world, mission, aircraft, tick);
            return true;
        }
        if (!flight.hasCompletedRoute(aircraft) && !flight.isParked(aircraft)) return false;

        if (mission.getState().canTransitionTo(MissionState.RECOVERING)) {
            mission.transitionTo(MissionState.RECOVERING, tick, "PATROL_ROUTE_COMPLETE");
        }
        flight.requestReturn(aircraft, "RDP_PATROL_COMPLETE");
        if (!flight.isReturning(aircraft)) {
            fail(world, mission, "PATROL_NATIVE_RETURN_REJECTED", tick);
            return true;
        }
        RDPMissionWorldData.get(world).markDirty();
        return true;
    }

    private void emitMissionSnapshot(RDPMission mission, MCH_EntityAircraft aircraft,
                                     Target target, long tick) {
        if (!RdpUavDebug.isMissionDiagnosticsEnabled() || tick % 5L != 0L) return;
        WingmanEntry entry = flight.getEntry(aircraft);
        double distance = target == null ? Double.NaN : targetDistance(aircraft, target);
        RdpUavDebug.event("MissionRuntime", "MISSION_SNAPSHOT",
                "mission", mission.getMissionId(), "aircraft", aircraft.getUniqueID(),
                "tick", tick, "state", mission.getState(), "phase", mission.getPhase(),
                "controlOwner", mission.getControlOwner(),
                "aircraftX", aircraft.posX, "aircraftY", aircraft.posY,
                "aircraftZ", aircraft.posZ, "yaw", aircraft.rotationYaw,
                "pitch", aircraft.rotationPitch, "motionX", aircraft.motionX,
                "motionY", aircraft.motionY, "motionZ", aircraft.motionZ,
                "target", formatTarget(target), "distance", distance,
                "targetId", mission.getTargetId(),
                "routeSize", entry == null || entry.mission == null ? 0 : entry.mission.size(),
                "missionIndex", entry == null ? -1 : entry.missionIndex,
                "nodeTimer", entry == null ? -1 : entry.missionNodeTimer,
                "autoTargetX", entry == null ? null : entry.autoTargetX,
                "autoTargetY", entry == null ? null : entry.autoTargetY,
                "autoTargetZ", entry == null ? null : entry.autoTargetZ,
                "node", entry == null || entry.currentNode() == null
                        ? null : entry.currentNode().type,
                "nativeState", entry == null ? null : entry.autoState);
    }

    private boolean atTarget(MCH_EntityAircraft aircraft, Target target, RDPMission mission) {
        if (target == null) return false;
        UavVehicleProfile profile = profile(aircraft);
        double dx = aircraft.posX - target.x;
        double dz = aircraft.posZ - target.z;
        if (profile.isReusable()) {
            net.vas.rdp.uav.world.TerrainObservation terrain = perception.observeTerrain(
                    aircraft.world, (int) Math.floor(aircraft.posX),
                    (int) Math.floor(aircraft.posZ), aircraft.world.getTotalWorldTime());
            if (!terrain.isKnown()) return false;
            return dx * dx + dz * dz
                    <= mission.getObservationDistance() * mission.getObservationDistance()
                    && Math.abs((aircraft.posY - terrain.getSurfaceY()) - profile.getCruiseAgl())
                    <= profile.getAltitudeTolerance();
        }
        double dy = aircraft.posY - target.y;
        return dx * dx + dy * dy + dz * dz
                <= mission.getObservationDistance() * mission.getObservationDistance();
    }

    private boolean withinMissionExecutionRange(MCH_EntityAircraft aircraft, Target target,
                                                 RDPMission mission) {
        if (target == null) return false;
        UavVehicleProfile profile = profile(aircraft);
        double dx = aircraft.posX - target.x;
        double dz = aircraft.posZ - target.z;
        if (profile.isReusable()) {
            return dx * dx + dz * dz
                    <= profile.getMissionExecutionRange() * profile.getMissionExecutionRange();
        }
        return targetDistance(aircraft, target) <= profile.getMissionExecutionRange();
    }

    private boolean terminalGeometrySatisfied(MCH_EntityAircraft aircraft, Target target,
                                               RDPMission mission) {
        if (aircraft == null || target == null || mission == null) return false;
        if (profile(aircraft).isReusable()) return true;
        double targetX = target.x;
        double targetY = target.y;
        double targetZ = target.z;
        ContactSnapshot tracked = mission.getTargetId() == null ? null : contact(mission.getTargetId());
        if (tracked != null && tracked.getLifecycle() != ContactLifecycle.EXPIRED
                && tracked.getLifecycle() != ContactLifecycle.LOST) {
            targetX = tracked.getAimX();
            targetY = tracked.getAimY();
            targetZ = tracked.getAimZ();
        }
        if (mission.getMissionType() == MissionType.SQUARE_STRIKE && mission.hasSquareArea()) {
            net.vas.rdp.uav.flight.SquareArea area =
                    new net.vas.rdp.uav.flight.SquareArea(
                            mission.getTargetSpec().getX(), mission.getTargetSpec().getZ(),
                            mission.getSquareWidth(), mission.getSquareDepth());
            return area.contains(aircraft.posX, aircraft.posZ)
                    && Math.abs(aircraft.posY - targetY) <= 3.0D;
        }
        double dx = aircraft.posX - targetX;
        double dz = aircraft.posZ - targetZ;
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        double vertical = Math.abs(aircraft.posY - targetY);
        // A point strike is terminal only at the resolved surface plane. The
        // old 3D-radius-only gate allowed a plane to detonate while hovering
        // tens of blocks above the square.
        return horizontal <= Math.max(4.0D, mission.getObservationDistance())
                && vertical <= 3.0D;
    }

    private double guidanceAltitude(MCH_EntityAircraft aircraft, double targetY) {
        UavVehicleProfile profile = profile(aircraft);
        if (!profile.isReusable()) {
            // FPV helicopters need a small, bounded standoff height before
            // their terminal dive. Sending the raw target Y to native WingMan
            // makes a ground target look like an unlimited descent/climb
            // correction for helicopter flight models.
            if (aircraft instanceof MCH_EntityHeli || profile.isHelicopterProfile()) {
                double minimum = profile.getMinimumExecutionAltitude() > 0D
                        ? profile.getMinimumExecutionAltitude() : 4D;
                double standoff = Math.max(profile.getCruiseAgl(), minimum);
                return Math.max(targetY + standoff, minimum);
            }
            return targetY + profile.getCruiseAgl();
        }
        return targetY + Math.max(profile.getMinimumAgl(),
                Math.min(profile.getMaximumAgl(), profile.getCruiseAgl()));
    }

    private double terminalRouteAltitude(MCH_EntityAircraft aircraft, Target target) {
        return guidanceAltitude(aircraft, target.y);
    }

    private Target resolvePointTarget(World world, double x, double requestedY, double z) {
        if (world == null) return Target.point(x, requestedY, z);
        net.minecraft.util.math.BlockPos column =
                new net.minecraft.util.math.BlockPos(x, 0, z);
        if (!world.isBlockLoaded(column)) return Target.point(x, requestedY, z);
        int surfaceY = world.getHeight(column).getY();
        double resolvedY = Math.max(requestedY, surfaceY + 1.0D
                + net.vas.rdp.uav.flight.SquareStrikeConfig.altitudeOffset);
        return Target.point(x, resolvedY, z);
    }

    private double aircraftSpeed(MCH_EntityAircraft aircraft) {
        return Math.sqrt(aircraft.motionX * aircraft.motionX
                + aircraft.motionY * aircraft.motionY + aircraft.motionZ * aircraft.motionZ);
    }

    static boolean isPermanentGuidanceFailure(String reason) {
        if (reason == null) return false;
        return "NO_GUIDED_WEAPON".equals(reason)
                || "UNSUPPORTED_GUIDANCE".equals(reason)
                || "UNSUPPORTED_OBJECTIVE_COMBINATION".equals(reason)
                || "AI_TV_GUIDANCE_UNSUPPORTED".equals(reason)
                || "UNSUPPORTED_SEEKER_TARGET_ASSIGNMENT".equals(reason)
                || "NATIVE_SEEKER_LAUNCH_REJECTED".equals(reason)
                || "NATIVE_WINGMAN_REJECTED".equals(reason)
                || "NO_AMMUNITION".equals(reason)
                || "REUSABLE_UAV_GUIDED_WEAPON_REQUIRED".equals(reason)
                || "ONE_WAY_SQUARE_TERMINAL_PAYLOAD_REQUIRED".equals(reason);
    }

    private UavVehicleProfile profile(MCH_EntityAircraft aircraft) {
        return UavVehicleProfiles.forAircraft(aircraft == null || aircraft.getAcInfo() == null
                ? null : aircraft.getAcInfo().name);
    }

    private MCH_EntityAircraft findAircraft(World world, UUID id) {
        if (id == null) return null;
        MCH_EntityAircraft aircraft = aircraftThisTick.get(id);
        if (aircraft != null && !aircraft.isDead
                && aircraft.dimension == world.provider.getDimension()) {
            return aircraft;
        }
        return null;
    }

    private Map<UUID, MCH_EntityAircraft> indexAircraft(World world) {
        Map<UUID, MCH_EntityAircraft> result = new HashMap<>();
        for (Entity entity : world.loadedEntityList) {
            // Piloted aircraft are valid mission platforms for native guided
            // weapon release even though WingMan itself only controls UAVs.
            // Filtering this index to isUAV() made aircraft such as the A-10
            // appear unavailable immediately after a weapon mission was
            // created.
            if (entity instanceof MCH_EntityAircraft && !entity.isDead
                    && entity.dimension == world.provider.getDimension()) {
                result.put(entity.getUniqueID(), (MCH_EntityAircraft) entity);
            }
        }
        return result;
    }

    private boolean isDirectNativeWeaponMission(RDPMission mission,
                                                 MCH_EntityAircraft aircraft) {
        return mission.isAttack() && aircraft != null && !aircraft.isUAV()
                && profile(aircraft).getExecutionProfile()
                != net.vas.rdp.uav.profile.UavExecutionProfile.ONE_WAY;
    }

    private String weaponPriority(RDPMission mission, MCH_EntityAircraft aircraft) {
        if (mission != null && mission.getGuidedWeapon() != null
                && !mission.getGuidedWeapon().trim().isEmpty()) {
            return mission.getGuidedWeapon();
        }
        return profile(aircraft).getAttackWeaponPriority();
    }

    private void launchDirectWeapon(World world, RDPMission mission,
                                    MCH_EntityAircraft aircraft, Target target, long tick) {
        GuidedStrikeObjective objective = target.entity == null
                ? GuidedStrikeObjective.square(mission.getMissionId(),
                world.provider.getDimension(), target.x, target.y, target.z, tick)
                : GuidedStrikeObjective.entity(mission.getMissionId(),
                target.entity.getUniqueID(), world.provider.getDimension(),
                target.x, target.y, target.z, tick);
        objective.authorize();
        objective.beginTracking();
        GuidedWeaponDecision decision = guidedWeapons.arm(world, aircraft, objective,
                aircraftSpeed(aircraft), profile(aircraft).getAttackEnvelope(), true,
                weaponPriority(mission, aircraft));
        if (!decision.isAccepted()) {
            RdpUavDebug.debug("Lifecycle",
                    "mission {} direct guided launch decision={} aircraft={} target={}",
                    mission.getMissionId(), decision.getReason(), aircraft.getUniqueID(),
                    formatTarget(target));
            if (isPermanentGuidanceFailure(decision.getReason())) {
                fail(world, mission, decision.getReason(), tick);
            } else {
                defer(world, mission, decision.getReason(),
                        guidanceRecoveryState(decision.getReason()), tick);
            }
            return;
        }
        objective.release();
        mission.transitionTo(MissionState.TARGET_LOCKED, tick);
        mission.transitionTo(MissionState.LAUNCH_ACCEPTED, tick);
        manager.release(mission);
        RDPMissionWorldData.get(world).markDirty();
    }

    private void fail(World world, RDPMission mission, String reason, long tick) {
        if (!terminal(mission.getState())) {
            MissionState previousState = mission.getState();
            mission.fail(reason, tick);
            LOGGER.warn("Mission {} FAILED reason={} previousState={} newState={} aircraft={} dimension={} tick={} age={}",
                    mission.getMissionId(), reason, previousState, mission.getState(),
                    mission.getAircraftId(), mission.getDimension(), tick,
                    Math.max(0L, tick - mission.getCreatedTick()));
            RdpUavDebug.event("Lifecycle", "mission_failed",
                    "mission", mission.getMissionId(),
                    "previousState", previousState,
                    "newState", mission.getState(),
                    "reason", reason,
                    "aircraft", mission.getAircraftId());
            boolean ownsAircraft = manager.ownsAssignment(mission);
            MCH_EntityAircraft aircraft = ownsAircraft
                    ? findAircraft(world, mission.getAircraftId()) : null;
            if (aircraft != null) flight.release(aircraft);
            if (ownsAircraft) routeRefreshes.remove(mission.getAircraftId());
            manager.release(mission);
            RDPMissionWorldData.get(world).markDirty();
        }
    }

    private void defer(World world, RDPMission mission, String reason,
                       MissionState recoveryState, long tick) {
        if (mission == null || mission.isTerminal()) return;
        boolean retained = mission.defer(reason, recoveryState, tick);
        if (!retained) {
            boolean ownsAircraft = manager.ownsAssignment(mission);
            MCH_EntityAircraft aircraft = ownsAircraft
                    ? findAircraft(world, mission.getAircraftId()) : null;
            if (aircraft != null) flight.release(aircraft);
            if (ownsAircraft) routeRefreshes.remove(mission.getAircraftId());
            manager.release(mission);
            RDPMissionWorldData.get(world).markDirty();
        } else {
            RdpUavDebug.debug("Lifecycle", "mission {} deferred state={} reason={} attempt={}",
                    mission.getMissionId(), recoveryState, reason, mission.getRecoveryAttempts());
            RDPMissionWorldData.get(world).markDirty();
        }
    }

    private String formatTarget(Target target) {
        return target == null ? "none" : target.entity == null
                ? String.format(java.util.Locale.ROOT, "point(%.1f,%.1f,%.1f)",
                target.x, target.y, target.z)
                : target.entity.getUniqueID() + "/" + EntityList.getKey(target.entity);
    }

    private MissionState guidanceRecoveryState(String reason) {
        if ("GUIDED_WAIT_TARGET_CHUNK".equals(reason)
                || "GUIDED_HOLD_CHUNK_UNLOADED".equals(reason)
                || "GUIDED_REJECT_DIMENSION".equals(reason)) {
            return MissionState.WAITING_FOR_WORLD;
        }
        return MissionState.REPLAN;
    }

    private String describeWingman(WingmanEntry entry) {
        if (entry == null) return "missing";
        MissionNodeView node = MissionNodeView.from(entry);
        return entry.autoState + " node=" + entry.missionIndex + "/" + node.size
                + " current=" + node.current;
    }

    private static final class MissionNodeView {
        private final int size;
        private final String current;

        private MissionNodeView(int size, String current) {
            this.size = size;
            this.current = current;
        }

        private static MissionNodeView from(WingmanEntry entry) {
            if (entry.mission == null) return new MissionNodeView(0, "none");
            com.norwood.mcheli.wingman.mission.MissionNode node = null;
            if (entry.missionIndex >= 0 && entry.missionIndex < entry.mission.size()) {
                node = entry.mission.get(entry.missionIndex);
            }
            return new MissionNodeView(entry.mission.size(), node == null ? "none" : node.type.name());
        }
    }

    private boolean requiresTarget(MissionState state) {
        return MissionSafety.requiresTarget(state);
    }

    private boolean terminal(MissionState state) {
        return state == MissionState.COMPLETE || state == MissionState.ABORTED
                || state == MissionState.FAILED || state == MissionState.KAMIKADZE_DETONATED
                || state == MissionState.AIRCRAFT_LOST;
    }

    private static final class Target {
        private final Entity entity;
        private final double x;
        private final double y;
        private final double z;

        private Target(Entity entity, double x, double y, double z) {
            this.entity = entity;
            this.x = x;
            this.y = y;
            this.z = z;
        }

        private static Target entity(Entity entity) {
            return new Target(entity, entity.posX, entity.posY, entity.posZ);
        }

        private static Target point(double x, double y, double z) {
            return new Target(null, x, y, z);
        }
    }

    private static final class RouteRefresh {
        private final long tick;
        private final double x;
        private final double y;
        private final double z;

        private RouteRefresh(long tick, double x, double y, double z) {
            this.tick = tick;
            this.x = x;
            this.y = y;
            this.z = z;
        }

        private double distanceSquared(double x, double y, double z) {
            double dx = this.x - x;
            double dy = this.y - y;
            double dz = this.z - z;
            return dx * dx + dy * dy + dz * dz;
        }
    }
}
